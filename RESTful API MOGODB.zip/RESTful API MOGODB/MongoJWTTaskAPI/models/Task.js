const mongoose = require('mongoose');

const taskSchema = new mongoose.Schema({

    taskName: {

        type: String,

        required: true

    },

    description: {

        type: String,

        required: true

    },

    completed: {

        type: Boolean,

        default: false

    }

});

module.exports = mongoose.model(
    'Task',
    taskSchema
);