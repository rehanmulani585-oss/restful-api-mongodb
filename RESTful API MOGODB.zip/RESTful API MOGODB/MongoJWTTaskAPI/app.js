const express = require('express');

const mongoose = require('mongoose');

const bcrypt = require('bcryptjs');

const jwt = require('jsonwebtoken');

const User = require('./models/User');

const Task = require('./models/Task');

const app = express();

const PORT = 3000;


// Middleware
app.use(express.json());


// Secret Key
const SECRET_KEY = "mysecretkey";


// MongoDB Connection
mongoose.connect(

    'mongodb://127.0.0.1:27017/jwttaskdb'

).then(() => {

    console.log('MongoDB Connected');

}).catch((error) => {

    console.log(error);

});


// HOME ROUTE
app.get('/', (req, res) => {

    res.json({

        message: "MongoDB JWT Task API Running"

    });

});


// REGISTER ROUTE
app.post('/register', async (req, res) => {

    try {

        const { username, password } = req.body;


        const existingUser =
            await User.findOne({ username });


        if (existingUser) {

            return res.status(400).json({

                error: "User already exists"

            });

        }


        const hashedPassword =
            await bcrypt.hash(password, 10);


        const user = new User({

            username,

            password: hashedPassword

        });


        await user.save();


        res.status(201).json({

            message: "User Registered Successfully"

        });

    } catch (error) {

        res.status(500).json({

            error: error.message

        });

    }

});


// LOGIN ROUTE
app.post('/login', async (req, res) => {

    try {

        const { username, password } = req.body;


        const user =
            await User.findOne({ username });


        if (!user) {

            return res.status(400).json({

                error: "Invalid Username"

            });

        }


        const isMatch =
            await bcrypt.compare(
                password,
                user.password
            );


        if (!isMatch) {

            return res.status(400).json({

                error: "Invalid Password"

            });

        }


        const token = jwt.sign(

            {

                id: user._id,

                username: user.username

            },

            SECRET_KEY,

            {

                expiresIn: '1h'

            }

        );


        res.json({

            message: "Login Successful",

            token

        });

    } catch (error) {

        res.status(500).json({

            error: error.message

        });

    }

});


// TOKEN MIDDLEWARE
function verifyToken(req, res, next) {

    const authHeader =
        req.headers.authorization;


    if (!authHeader) {

        return res.status(401).json({

            error: "No Token Provided"

        });

    }


    const token =
        authHeader.split(' ')[1];


    try {

        const verified =
            jwt.verify(token, SECRET_KEY);

        req.user = verified;

        next();

    } catch (error) {

        res.status(400).json({

            error: "Invalid Token"

        });

    }

}


// CREATE TASK
app.post('/tasks', verifyToken, async (req, res) => {

    try {

        const task = new Task(req.body);

        await task.save();


        res.status(201).json({

            message: "Task Created Successfully",

            task

        });

    } catch (error) {

        res.status(400).json({

            error: error.message

        });

    }

});


// GET ALL TASKS
app.get('/tasks', verifyToken, async (req, res) => {

    try {

        const tasks = await Task.find();

        res.json(tasks);

    } catch (error) {

        res.status(500).json({

            error: error.message

        });

    }

});


// UPDATE TASK
app.put('/tasks/:id', verifyToken, async (req, res) => {

    try {

        const task =
            await Task.findByIdAndUpdate(

                req.params.id,

                req.body,

                { new: true }

            );


        if (!task) {

            return res.status(404).json({

                error: "Task Not Found"

            });

        }


        res.json({

            message: "Task Updated Successfully",

            task

        });

    } catch (error) {

        res.status(400).json({

            error: error.message

        });

    }

});


// DELETE TASK
app.delete('/tasks/:id', verifyToken, async (req, res) => {

    try {

        const task =
            await Task.findByIdAndDelete(
                req.params.id
            );


        if (!task) {

            return res.status(404).json({

                error: "Task Not Found"

            });

        }


        res.json({

            message: "Task Deleted Successfully"

        });

    } catch (error) {

        res.status(500).json({

            error: error.message

        });

    }

});


// START SERVER
app.listen(PORT, () => {

    console.log(

        `Server running on http://localhost:${PORT}`

    );

});